const PORT = 3000;
const express = require('express');
const morgan = require('morgan');
const mongoose = require('mongoose');
require('dotenv').config();
const bcrypt = require('bcrypt');
const { User } = require('./schema/users');
const { users } = require('./data/users.json')

const { exercises } = require('./data/exercise.json')
const { Exercise } = require('./schema/exercise')

const userRouter = require('./routers/users');
const bizUserRouter = require('./routers/bizUsers');
const bizTraineesRouter = require('./routers/trainees');
const exerciseRouter = require('./routers/exercise');

const app = express();

app.use(morgan('dev'));
app.use(express.json());

app.use('/api/user', userRouter);
app.use('/api/bizuser/trainee', bizTraineesRouter)
app.use('/api/bizuser', bizUserRouter);
app.use('/api/exercise', exerciseRouter);


async function connect() {
    await mongoose.connect('mongodb://localhost:27017/FitPlanApi')
        .then(() => console.log('Connected to MongoDB'))
        .then(() => {
            createUsers();
            createExercize();
        })
        .catch(err => console.log('Could not connect to MongoDB: ', err));

    app.listen(PORT, () => {
        console.log("running port " + PORT);
    })
}

connect();

async function createUsers() {
    const usersFromDb = await User.find();
    users.forEach(async user => {
        if (usersFromDb.find((dbUser) => dbUser.email === user.email)) {
            return;
        }
        const newUser = new User(user);
        newUser.password = await bcrypt.hash(newUser.password, 12);
        newUser.save();
    });
}
async function createExercize() {
    const exercisesFromDb = await Exercise.find();
    if (exercisesFromDb.length > 0) {
        return;
    }
    exercises.forEach(async ex => {
        const newEx = new Exercise(ex);
        newEx.save();
    });
}



