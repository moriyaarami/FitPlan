const { BizUser } = require('../schema/bizuser');
const { Trainee } = require('../schema/trainee')

module.exports = getMyTraineePlanMw = async (req, res, next) => {

    const bizuser = await BizUser.findById(req.user._id);
    if (!bizuser) {
        res.status(400).send('not found business user');
        return;
    }

    const myTrainees = bizuser.myTrinees;

    if (myTrainees.length == 0) {
        res.status(400).send('not found any trainees');
        return;
    }

    let trainee = myTrainees.find(trainee => trainee._id == req.params.TraineeId);

    if (!trainee) {
        res.status(400).send('not found trainee for this business user');
        return;
    }

    trainee = await Trainee.findById(trainee._id);

    req.traineePlan = trainee.myPlan
    next();

};