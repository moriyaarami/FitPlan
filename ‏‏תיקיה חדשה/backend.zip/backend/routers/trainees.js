const express = require('express');
const { Trainee, validateTrainee, validateUpdateTrainee } = require('../schema/trainee');
const { BizUser } = require('../schema/bizuser');
const { Exercise } = require('../schema/exercise')

const authMW = require('../middleware/auth');
const getMyTraineePlanMw = require('../middleware/getTraineePlan')

const router = express.Router();

router.post('/add', authMW, async (req, res) => {
    const { error } = validateTrainee(req.body);
    if (error) {
        res.status(400).send(error.details[0].message);
        return;
    }
    let bizUser = await BizUser.findById(req.user._id);
    if (!bizUser) {
        res.status(400).send('just bisness user can perform this action.');
        return;
    }

    let trainee = await Trainee.findOne({ phone: req.body.phone });
    if (trainee) {
        res.status(400).send('Trainee already exists.');
        return;
    }

    trainee = await new Trainee({ ...req.body, user_id: req.user._id });
    await bizUser.myTrinees.push(trainee);


    await trainee.save();
    await bizUser.save()
    res.send(trainee);
    return;

})

/* router.get('/', authMW, async (req, res) => {
    if (!req.user.isAdmin) {
        res.send('just admin user can access this action');
        return;
    }

    const trainees = await Trainee.find({ user_id: req.user._id });
    if (trainees.length == 0) {
        res.status(400).send('have not trainees for this user');
        return;
    }

    res.send(trainees)
    return;

}) */

router.get('/myTrainees', authMW, async (req, res) => {
    const bizUser = await BizUser.findById(req.user._id);
    if (!bizUser) {
        res.status(400).send('not found business user');
        return;
    }

    res.send(bizUser.myTrinees)
})
router.get('/:id', authMW, async (req, res) => {

    const bizUser = await BizUser.findById(req.user._id);
    if (!bizUser) {
        res.status(400).send('not found business user');
        return;
    }

    /* מציאת כל המתאמנים של המשתמש העסקי */
    const Trainees = await Trainee.find({ user_id: req.user._id });

    /* להשיג את המתאמן הספציפי */

    if (Trainees.length == 0) {
        res.status(400).send('not found trainee');
        return;
    }


    const trainee = Trainees.filter(trainee => trainee._id == req.params.id);
    if (trainee.length == 0) {
        res.status(400).send('not found trainee with this id');
        return;
    }
    res.send(trainee);
    return;
})



router.put('/:id', authMW, async (req, res) => {
    const { error } = validateUpdateTrainee(req.body);
    if (error) {
        res.status(400).send(error.details[0].message);
        return;
    }

    let bizuser = await BizUser.findById(req.user._id);
    if (!bizuser) {
        res.status(400).send('not found business user');
        return;
    }

    const Trainees = await Trainee.find({ user_id: req.user._id });

    /*  const traineeUserId = Trainees.map(trainee => trainee.user_id); */

    if (Trainees.length == 0) {
        res.status(400).send('not found trainees for user');
        return;
    }

    let trainee = await Trainee.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!trainee) {
        res.status(400).send('not found trainee with this id');
        return;
    }

    res.send(trainee);
    return;



})

router.delete('/:id', authMW, async (req, res) => {
    const bizUser = await BizUser.findById(req.user._id);
    if (!bizUser) {
        res.status(400).send('not found business user');
        return;
    }
    const Trainees = await Trainee.find({ user_id: req.user._id });

    if (Trainees.length == 0) {
        res.status(400).send('the operation failed.');
        return;
    }

    const trainee = await Trainee.findByIdAndDelete(req.params.id);
    if (!trainee) {
        res.status(400).send('not found trainee with this id');
        return;
    }

    res.send(`the trainee:${trainee.name} deleted successfully.`);
    return;

})

router.patch('/addToTraineePlan/:TraineeId', authMW, getMyTraineePlanMw, async (req, res) => {

    const { exerciseId, sets, reps, weight } = req.body;

    const myPlan = req.traineePlan;

    const exercise = await Exercise.findById(exerciseId);
    if (!exercise) {
        res.status(400).send('Exercise not found');
        return;
    }

    const hasEX = myPlan.some(ex => {
        return ex.exerciseId.toString() === exercise._id.toString();
    })
    console.log(hasEX)
    if (hasEX) {
        res.status(400).send('Exercise already exists in the plan');
        return;
    }

    await myPlan.push({ exerciseId, sets, reps, weight });

    const updatedTrainee = await Trainee.findByIdAndUpdate(req.params.TraineeId, { myPlan }, { new: true });
    res.json(updatedTrainee.myPlan);
    return;

})

router.patch('/removeFromTraineePlan/:TraineeId', authMW, getMyTraineePlanMw, async (req, res) => {
    const { exerciseId } = req.body;
    console.log(exerciseId);

    const myPlan = req.traineePlan;

    const exercise = await Exercise.findById(exerciseId);
    if (!exercise) {
        res.status(400).send('Exercise not found');
        return;
    }

    const hasEX = myPlan.some(ex => {
        return ex.exerciseId.toString() === exercise._id.toString();
    })

    if (!hasEX) {
        res.status(400).send('not found this exercise in your plan');
        return;
    }

    const updatedUser = await Trainee.findByIdAndUpdate(req.params.TraineeId, { $pull: { myPlan: { exerciseId: exercise._id } } }, { new: true });

    res.json(updatedUser.myPlan);
    return;
})

module.exports = router;