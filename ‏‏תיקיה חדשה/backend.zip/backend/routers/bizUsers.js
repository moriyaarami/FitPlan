const express = require('express');

const { User } = require('../schema/users');
const { Trainee } = require('../schema/trainee');

const { BizUser, validateBizUser, validateLogin, validateUpdateBizUser } = require('../schema/bizuser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const config = require('../config/config');
const authMW = require('../middleware/auth');

const router = express.Router();

router.post('/signup', async (req, res) => {
    const { error } = validateBizUser(req.body);
    if (error) {
        res.status(400).send(error.details[0].message);
        return;
    }

    let bizuser = await BizUser.findOne({ email: req.body.email });
    let user = await User.findOne({ email: req.body.email });

    if (bizuser || user) {
        res.status(400).send('User already exists.');
        return;
    }

    bizuser = await new BizUser(req.body);
    bizuser.password = await bcrypt.hash(bizuser.password, 12);
    await bizuser.save();
    res.json(bizuser);
    return;
})

router.post('/login', async (req, res) => {
    const { error } = validateLogin(req.body);
    if (error) {
        res.status(400).send(error.details[0].message);
        return;
    }

    const bizuser = await BizUser.findOne({ email: req.body.email });

    if (!bizuser) {
        res.status(400).send('Invalid email or password.');
        return;
    }

    const validatePassword = await bcrypt.compare(req.body.password, bizuser.password);

    if (!validatePassword) {
        res.status(400).send('Invalid email or password.');
        return;
    }

    const token = jwt.sign({ _id: bizuser._id, admin: bizuser.isAdmin, biz: bizuser.isBusiness }, config.jwtKey);
    res.json({ token });
    return;
})

router.get('/', authMW, async (req, res) => {
    if (!req.user.admin) {
        res.status(400).send('You do not have permission to perform this action,you must to be admin user.');
        return;
    }

    const users = await BizUser.find();
    res.json(users);
})

router.get('/:id', authMW, async (req, res) => {
    const registeredUser = req.params.id === req.user._id ? true : false;
    const admin = req.user.admin;

    if (registeredUser || admin) {
        const user = await BizUser.findById(req.params.id);
        if (!user) {
            res.status(404).send('User not found.');
            return;
        }
        res.json(user);
        return;
    }

    res.status(401).send(`You do not have permission to perform this action`);
    return;

})

router.put('/:id', authMW, async (req, res) => {
    const { error } = validateUpdateBizUser(req.body);
    if (error) {
        res.status(400).send(error.details[0].message);
        return;
    }

    const registeredUser = req.params.id === req.user._id ? true : false;
    const admin = req.user.admin;


    if (registeredUser || admin) {
        const user = await BizUser.findByIdAndUpdate({ _id: req.params.id }, req.body, { new: true });

        if (!user) {
            res.status(400).send('Not Found user with this id.');
            return;
        }
        res.send(user);
        return;
    }

    res.status(401).send(`You do not have permission to perform this action.`);
    return;



})

/* router.patch('/:id', authMW, async (req, res) => {

    const registeredUser = req.params.id === req.user._id ? true : false;
    const admin = req.user.admin;

    if (registeredUser || admin) {
        const user = await BizUser.findById(req.user._id);
        if (!user) {
            res.status(404).send(`you do not have permission to access the user's details`);
            return;
        }
        console.log(req.user._id)
        const mytrainees = await Trainee.find({ user_id: req.user._id });
        if (!mytrainees || mytrainees.length == 0) {
            res.status(404).send(`you have not trainees yet`);
            return;
        }

        await user.myTrinees.push(mytrainees);
        await user.save()
        res.send(user.myTrinees);
        return;

    }
    res.status(401).send(`you do not have permission to access the user's details`);
    return;

}) */

router.delete('/:id', authMW, async (req, res) => {
    const adminUser = req.user.admin;
    const registeredUser = req.params.id === req.user._id ? true : false;

    if (adminUser || registeredUser) {
        const user = await BizUser.findByIdAndDelete(req.params.id);
        if (!user) {
            res.status(404).send('No user found with this id.');
        }
        res.send(`the user:${user.name} deleted successfully.`);
        return;
    }
    res.status(400).send("just admin user or registered user can delete the user");
    return;

})

router.get('/:id/getmyTrainee/:trainee_id', authMW, async (req, res) => {
    const registeredUser = req.params.id === req.user._id ? true : false; if (registeredUser) {
        const user = await BizUser.findById(req.params.id);
        if (!user) {
            res.status(404).send('User not found.');
            return;
        }

        const trainee = await Trainee.findById(req.params.trainee_id);
        if (!trainee) return res.status(404).send('Trainee not found.');
        if (!(trainee.user_id === user._id)) {
            res.status(404).send('not found');
        }

        res.send(trainee);
        return;
    };

    res.status(401).send(`You do not have permission to perform this action.`);
    return;
})



module.exports = router;
